# SDMetrics
Metrics To Compare Temporally Explicit Species Distribution Models

How can temporally-explicit species distribution models be compared to study changing distributions? This R package contains tools developed to infer the presence and type of seasonal animal migration from season-specific SDM. Currently in beta development.
